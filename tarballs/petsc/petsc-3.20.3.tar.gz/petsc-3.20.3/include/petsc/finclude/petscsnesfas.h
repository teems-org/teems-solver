!
!  Include file for Fortran use of the FAS nonlinear solvers in PETSc
!
#if !defined (PETSCSNESFASDEF_H)
#define PETSCSNESFASDEF_H

#include "petsc/finclude/petscsnes.h"

#define SNESFASType PetscEnum

#endif
